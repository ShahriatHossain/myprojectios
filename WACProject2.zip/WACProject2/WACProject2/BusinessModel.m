//
//  BusinessModel.m
//  WACProject2
//
//  Created by ImpleVista on 8/17/15.
//  Copyright (c) 2015 ImpleVista. All rights reserved.
//

#import "BusinessModel.h"

@implementation BusinessModel

@end
