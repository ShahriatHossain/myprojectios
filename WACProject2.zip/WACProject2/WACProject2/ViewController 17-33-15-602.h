//
//  ViewController.h
//  WACProject2
//
//  Created by ImpleVista on 8/13/15.
//  Copyright (c) 2015 ImpleVista. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController <UICollectionViewDelegate,UICollectionViewDataSource>

@end
