//
//  CollectionViewController.h
//  WACProject2
//
//  Created by ImpleVista on 8/14/15.
//  Copyright (c) 2015 ImpleVista. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CollectionViewController : UIViewController <UICollectionViewDelegate,UICollectionViewDataSource>

@end
