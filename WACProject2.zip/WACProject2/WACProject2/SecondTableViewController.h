//
//  SecondTableViewController.h
//  WACProject2
//
//  Created by ImpleVista on 8/12/15.
//  Copyright (c) 2015 ImpleVista. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SecondTableViewController : UITableViewController

@property(nonatomic, strong) NSString *businessName;

@end
