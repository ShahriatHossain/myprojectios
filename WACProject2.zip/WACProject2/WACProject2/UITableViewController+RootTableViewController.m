//
//  UITableViewController+RootTableViewController.m
//  WACProject2
//
//  Created by ImpleVista on 8/12/15.
//  Copyright (c) 2015 ImpleVista. All rights reserved.
//

#import "UITableViewController+RootTableViewController.h"

@implementation UITableViewController (RootTableViewController)

@end
